<?php

namespace Exceptions;

require '../vendor/autoload.php';

class PluginNotFoundException extends \Exception
{
}
