<?php

namespace Exceptions;

require '../vendor/autoload.php';

class InvalidKeyException extends \Exception
{
}
