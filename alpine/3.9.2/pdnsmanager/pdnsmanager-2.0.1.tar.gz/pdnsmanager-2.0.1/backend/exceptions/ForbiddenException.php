<?php

namespace Exceptions;

require '../vendor/autoload.php';

class ForbiddenException extends \Exception
{
}
