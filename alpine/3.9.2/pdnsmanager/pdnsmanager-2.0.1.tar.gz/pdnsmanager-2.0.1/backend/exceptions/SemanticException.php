<?php

namespace Exceptions;

require '../vendor/autoload.php';

class SemanticException extends \Exception
{
}
