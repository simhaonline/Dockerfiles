<?php

namespace Exceptions;

require '../vendor/autoload.php';

class AlreadyExistentException extends \Exception
{
}
