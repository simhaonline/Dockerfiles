<?php

namespace Exceptions;

require '../vendor/autoload.php';

class NotFoundException extends \Exception
{
}
